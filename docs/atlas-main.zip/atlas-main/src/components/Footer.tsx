
"use client";

import React from "react";
import Link from "next/link";
import { Shield } from "lucide-react";

export function Footer() {
  return (
    <footer className="py-20 bg-brand-charcoal border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <Shield className="text-brand-gold w-6 h-6" />
              <span className="font-headline text-xl font-bold tracking-tight text-off-white uppercase">
                ATLAS <span className="text-brand-gold font-normal italic">WEALTH OS</span>
              </span>
            </div>
            <p className="text-muted-foreground max-w-sm mb-6">
              The premium family office operating system for the next generation of global wealth owners. Manage everything in one place.
            </p>
          </div>
          
          <div>
            <h5 className="font-bold mb-6 uppercase text-sm tracking-widest text-brand-gold">Product</h5>
            <ul className="space-y-4">
              <li><Link href="/features" className="text-muted-foreground hover:text-off-white transition-colors">Features</Link></li>
              <li><Link href="/security" className="text-muted-foreground hover:text-off-white transition-colors">Security</Link></li>
              <li><Link href="/architecture" className="text-muted-foreground hover:text-off-white transition-colors">Architecture</Link></li>
              <li><Link href="/request-access" className="text-muted-foreground hover:text-off-white transition-colors">Request Access</Link></li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-bold mb-6 uppercase text-sm tracking-widest text-brand-gold">Company</h5>
            <ul className="space-y-4">
              <li><Link href="/about" className="text-muted-foreground hover:text-off-white transition-colors">About Us</Link></li>
              <li><Link href="/contact" className="text-muted-foreground hover:text-off-white transition-colors">Contact</Link></li>
              <li><Link href="/privacy" className="text-muted-foreground hover:text-off-white transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms" className="text-muted-foreground hover:text-off-white transition-colors">Terms of Use</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Atlas Wealth Systems. All rights reserved. Not financial advice.
          </p>
          <div className="flex gap-6 text-xs text-muted-foreground">
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-off-white transition-colors">LinkedIn</a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:text-off-white transition-colors">Twitter</a>
            <Link href="/portal" className="hover:text-off-white transition-colors">Institutional Portal</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
